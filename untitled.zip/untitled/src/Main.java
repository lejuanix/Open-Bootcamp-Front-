
public class Main {

    public static void main(String[] args){ // llamado a MAIN y Valores.
        suma(10,30,20);
        coche miCoche= new coche();
        miCoche.Agregarpuertas();

        System.out.println(miCoche.puertas);
    }
    public static void suma(int a, int b, int c) { // Primera Parte.
        int resultado = a + b + c;

            System.out.println(resultado);
    }
}
class coche { // Segunda Parte.
    public int puertas = 0;

    public void Agregarpuertas() {
        this.puertas++;
    }
}

